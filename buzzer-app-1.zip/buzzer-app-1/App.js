import React, { Component } from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
export default class App extends Component {
  render() {
    return (
      <View>
        <Button title="GO" color="red"></Button>
        <Text> button stage 1 </Text>
      </View>
    );
  }
}
